"""Инициализация пакета."""
__version__ = "0.2.19"  # Можно хранить версию тут

from .main import Statgram
