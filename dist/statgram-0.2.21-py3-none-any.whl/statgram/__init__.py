"""Инициализация пакета."""
__version__ = "0.2.21"  # Можно хранить версию тут

from .main import Statgram
