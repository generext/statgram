"""Инициализация пакета."""
from .main import Statgram
