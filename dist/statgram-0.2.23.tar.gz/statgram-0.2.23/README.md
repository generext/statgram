# Statgram

Statgram - AI Аналитика и админ панель с ИИ для любых текстовых вопросов по метрикам сразу после подключения для чат ботов и mini apps в Telegram

Подробнее на statgram.org

## Установка
```sh
pip install statgram